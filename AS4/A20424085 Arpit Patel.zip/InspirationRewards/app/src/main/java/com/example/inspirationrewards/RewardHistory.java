package com.example.inspirationrewards;

public class RewardHistory {
    String name,point,date,note;

    public RewardHistory(){

    }
    public RewardHistory(String name, String point, String date, String note) {
        this.name = name;
        this.point = point;
        this.date = date;
        this.note = note;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
