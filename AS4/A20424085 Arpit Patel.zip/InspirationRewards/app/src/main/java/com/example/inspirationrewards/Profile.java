package com.example.inspirationrewards;

public class Profile {

    String userName,dep,position,story;
    String point,firstName,lastName;

    public Profile(){

    }
    public Profile(String userName, String dep, String position,String point,String firstName,String lastName,String story) {
        this.userName = userName;
        this.dep=dep;
        this.position=position;
        this.point = point;
        this.firstName=firstName;
        this.lastName=lastName;
        this.story=story;
    }

    public String getStory() {
        return story;
    }

    public void setStory(String story) {
        this.story = story;
    }

    public String getUserName() {
        return userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDep() {
        return dep;
    }

    public void setDep(String dep) {
        this.dep = dep;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }
}
