package com.example.inspirationrewards;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;

public class LeaderBoardAdapter extends RecyclerView.Adapter<LeaderBoardAdapter.MyViewHolder> {

    private List<Profile> allDataList;
    List<String> allImg;
    private static ClickListener clickListener;

    public LeaderBoardAdapter(List<Profile> allDataList,List<String> allImg){
        this.allDataList=allDataList;
        this.allImg=allImg;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.leaderboard_single,viewGroup,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {

        Profile p=allDataList.get(i);
        myViewHolder.uName.setText(p.getFirstName()+","+p.getLastName());
        myViewHolder.dep.setText(p.getDep());
        myViewHolder.pos.setText(p.getPosition());
        myViewHolder.point.setText(p.getPoint());

        InputStream stream = new ByteArrayInputStream(Base64.decode(allImg.get(i).getBytes(), Base64.DEFAULT));

        Bitmap bitmap = BitmapFactory.decodeStream(stream);

        myViewHolder.imageView.setImageBitmap(bitmap);

    }

    @Override
    public int getItemCount() {
        return allDataList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView uName,dep,pos,point;
        ImageView imageView;
        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            itemView.setOnClickListener(this);
            uName=itemView.findViewById(R.id.leaderboard_single_username);
            dep=itemView.findViewById(R.id.leaderboard_single_department);
            pos=itemView.findViewById(R.id.leaderboard_single_position);
            point=itemView.findViewById(R.id.leaderboard_single_point);
            imageView=itemView.findViewById(R.id.single_leaderboard_pic);

        }

        @Override
        public void onClick(View v) {
            clickListener.onItemClick(getAdapterPosition(), v);
        }

    }

    public void setOnItemClickListener(ClickListener clickListener) {
        LeaderBoardAdapter.clickListener = clickListener;
    }

    public interface ClickListener {
        void onItemClick(int position, View v);
    }
}
