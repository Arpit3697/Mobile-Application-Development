package com.example.inspirationrewards;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.example.inspirationrewards.AsyncTask.UpdateProfileAPIAsyncTask;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class UpdateProfile extends AppCompatActivity {

    EditText uName,password,firstName,lastName,department,position,story;
    ImageView pic;
    String data;
    public static final int PICK_IMAGE = 1;
    Bitmap selectedImageSave;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.save_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()) {

            case R.id.save_button:

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                selectedImageSave.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                String im= Base64.encodeToString(byteArray,Base64.DEFAULT);

                new UpdateProfileAPIAsyncTask(this).execute("A20424085", uName.getText().toString(),
                        password.getText().toString(), firstName.getText().toString(), lastName.getText().toString(),
                        department.getText().toString(), position.getText().toString(), story.getText().toString(),im);
                break;

            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            try {
                final Uri imageUri = data.getData();
                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                selectedImageSave=selectedImage;
                pic.setImageBitmap(selectedImage);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(UpdateProfile.this, "Something went wrong", Toast.LENGTH_LONG).show();
            }

        }else {
            Toast.makeText(UpdateProfile.this, "You haven't picked Image",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        uName=findViewById(R.id.edit_profile_username);
        password=findViewById(R.id.edit_profile_password);
        firstName=findViewById(R.id.edit_profile_firstname);
        lastName=findViewById(R.id.edit_profile_lastname);
        department=findViewById(R.id.edit_profile_department);
        position=findViewById(R.id.edit_profile_position);
        story=findViewById(R.id.edit_profile_story);
        pic=findViewById(R.id.edit_profile_pic);
        uName.setEnabled(false);

        Intent i=getIntent();
        data=i.getStringExtra("YourProfileData");

        try{

            getSupportActionBar().setTitle("Edit Profile");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            JSONObject js=new JSONObject(data);

            uName.setText(js.getString("username"));
            password.setText(js.getString("password"));
            firstName.setText(js.getString("firstName"));
            lastName.setText(js.getString("lastName"));
            department.setText(js.getString("department"));
            position.setText(js.getString("position"));
            story.setText(js.getString("story"));
            InputStream stream = new ByteArrayInputStream(Base64.decode(js.getString("imageBytes").getBytes(), Base64.DEFAULT));
            Bitmap bitmap = BitmapFactory.decodeStream(stream);
            pic.setImageBitmap(bitmap);



            pic.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                    photoPickerIntent.setType("image/*");
                    startActivityForResult(photoPickerIntent, PICK_IMAGE);
                }
            });

            }catch (Exception e){
            Log.e("UpdateProfile","Error in JsonObjcet");
        }

    }

    public void displayToast(String result) {
        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
        Intent i=new Intent(UpdateProfile.this,YourProfile.class);
        i.putExtra("Details",data);
        startActivity(i);
        if(result.equals("Success")){
            startActivity(new Intent(UpdateProfile.this,YourProfile.class));
        }
    }
}
