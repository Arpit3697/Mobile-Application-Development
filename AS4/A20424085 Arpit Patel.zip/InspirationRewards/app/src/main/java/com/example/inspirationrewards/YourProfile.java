package com.example.inspirationrewards;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class YourProfile extends AppCompatActivity {

    TextView FLName,uName,story,dpt,pos,points;
    ImageView pic;
    String data;
    int totalValue;
    RecyclerView rewardRecyclerView;
    List<RewardHistory> allRewardData=new ArrayList<>();
    RewardHistoryAdapter mRewardAdapter;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.your_profile_menu,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.edit_button:

                Intent i=new Intent(YourProfile.this,UpdateProfile.class);
                i.putExtra("YourProfileData",data);
                startActivity(i);
                break;
            case R.id.sort_button:

                Intent leadActivity =new Intent(YourProfile.this,LeaderBoard.class);
                leadActivity.putExtra("Personal",data);
                startActivity(leadActivity);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_profile);

        Intent i =getIntent();
        data=i.getStringExtra("Details");

        FLName=findViewById(R.id.your_profile_FLname);
        dpt=findViewById(R.id.your_profile_department);
        pos=findViewById(R.id.your_profile_position);
        story=findViewById(R.id.your_profile_story);
        pic=findViewById(R.id.your_profile_pic);
        points=findViewById(R.id.your_profile_points);

        rewardRecyclerView=findViewById(R.id.your_profile_recyclerview);
        mRewardAdapter=new RewardHistoryAdapter(allRewardData);
        RecyclerView.LayoutManager mLayoutManager=new LinearLayoutManager(getApplicationContext());
        rewardRecyclerView.setLayoutManager(mLayoutManager);
        rewardRecyclerView.addItemDecoration(new DividerItemDecoration(rewardRecyclerView.getContext(), DividerItemDecoration.VERTICAL));

        rewardRecyclerView.setAdapter(mRewardAdapter);


        try{

            getSupportActionBar().setTitle("Your Profile");
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setLogo(R.drawable.icon);
            getSupportActionBar().setDisplayUseLogoEnabled(true);

            JSONObject js=new JSONObject(data);

            String imgFromServer=js.getString("imageBytes");

            FLName.setText(js.getString("firstName")+" ,"+js.getString("lastName")+"("+js.getString("username")+")");
            dpt.setText(js.getString("department"));
            pos.setText(js.getString("position"));
            story.setText(js.getString("story"));


            JSONArray array2=new JSONArray(js.getString("rewards"));

            for(int j=0;j<array2.length();j++){

                JSONObject jsonObject=array2.getJSONObject(j);

                String total=jsonObject.getString("value");
                totalValue=totalValue + Integer.parseInt(total);

                RewardHistory r=new RewardHistory(jsonObject.getString("name"),jsonObject.getString("value"),
                        jsonObject.getString("date"),jsonObject.getString("notes"));

                allRewardData.add(r);
            }


            InputStream stream = new ByteArrayInputStream(Base64.decode(imgFromServer.getBytes(), Base64.DEFAULT));

            Bitmap bitmap = BitmapFactory.decodeStream(stream);

            pic.setImageBitmap(bitmap);

            points.setText(totalValue+"");
            mRewardAdapter.notifyDataSetChanged();

        }catch (Exception e){
            Log.e("YourProfile","Error in JsonObjcet");
        }


    }//End of OnCreate() method
}
