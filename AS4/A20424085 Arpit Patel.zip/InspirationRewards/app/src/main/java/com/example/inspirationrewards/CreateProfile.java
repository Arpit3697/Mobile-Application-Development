package com.example.inspirationrewards;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.inspirationrewards.AsyncTask.CreateProfileAPIAsyncTask;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class CreateProfile extends AppCompatActivity {

    EditText uName,password,firstName,lastName,department,position,story;
    ImageView pic;
    public static final int PICK_IMAGE = 1;
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    Bitmap selectedImageSave;
    CheckBox checkBox;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.save_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()){
            case R.id.save_button:

                try{

                    if (checkSelfPermission(Manifest.permission.CAMERA)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA},
                                MY_CAMERA_REQUEST_CODE);
                    }

                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    selectedImageSave.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
                    byte[] byteArray = byteArrayOutputStream.toByteArray();

                    String im= Base64.encodeToString(byteArray,Base64.DEFAULT);

                    if(TextUtils.isEmpty(im)){
                        Toast.makeText(getApplicationContext(),"select profile Pic",Toast.LENGTH_SHORT).show();
                    }else{

                        String adminCheck;
                        if(checkBox.isChecked()){
                            adminCheck="yes";
                        }else{
                            adminCheck="no";
                        }

                        new CreateProfileAPIAsyncTask(this).execute("A20424085",uName.getText().toString(),
                                password.getText().toString(),firstName.getText().toString(),lastName.getText().toString(),
                                department.getText().toString(),position.getText().toString(),story.getText().toString(),im,adminCheck);
                    }

                }catch (Exception e){
                    e.printStackTrace();
                    Log.e(">>>CreateProfile","Creating error");
                    Toast.makeText(getApplicationContext(),"Enter all data and image",Toast.LENGTH_SHORT).show();
                }

                break;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            try {
                final Uri imageUri = data.getData();
                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                selectedImageSave=selectedImage;
                pic.setImageBitmap(selectedImage);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(CreateProfile.this, "Something went wrong", Toast.LENGTH_LONG).show();
            }

        }else {
            Toast.makeText(CreateProfile.this, "You haven't picked Image",Toast.LENGTH_LONG).show();
        }
    }

    @Override

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_CAMERA_REQUEST_CODE) {

            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();

            } else {

                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();

            }

        }}//end onRequestPermissionsResult
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_profile);

        getSupportActionBar().setTitle("Create Profile");
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.arrow_with_logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        uName=findViewById(R.id.single_leaderboard_pic);
        password=findViewById(R.id.create_password);
        firstName=findViewById(R.id.create_first_name);
        lastName=findViewById(R.id.create_last_name);
        department=findViewById(R.id.create_department);
        position=findViewById(R.id.create_position);
        story=findViewById(R.id.create_story);
        pic=findViewById(R.id.create_user_pic);
        checkBox=findViewById(R.id.create_profile_adminBox);

        pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, PICK_IMAGE);

            }
        });


    }//End of OnCreate() method

    public void displayToast(String result){

        if(result.equals("Success")){
            startActivity(new Intent(CreateProfile.this,MainActivity.class));
        }
    }
}
