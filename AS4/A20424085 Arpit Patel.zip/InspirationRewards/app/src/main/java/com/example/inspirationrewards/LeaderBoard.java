package com.example.inspirationrewards;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import com.example.inspirationrewards.AsyncTask.GetAllProfilesAPIAsynkTask;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class LeaderBoard extends AppCompatActivity {

    List<Profile> allProfileDataList=new ArrayList<>();
    List<String> allStdId=new ArrayList<>();
    List<String> imgStoreList=new ArrayList<>();
    RecyclerView recyclerView;
    LeaderBoardAdapter leaderBoardAdapter;
    int totalValue;

    String userName,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leader_board);

        getSupportActionBar().setTitle("Inspiration Leaderboard");
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        Intent getData=getIntent();
        String data= getData.getStringExtra("Personal");

        String uN=getData.getStringExtra("Uname");
        String ps=getData.getStringExtra("Pass");

        recyclerView=findViewById(R.id.recyclerview);
        leaderBoardAdapter =new LeaderBoardAdapter(allProfileDataList,imgStoreList);
        RecyclerView.LayoutManager mLayoutManager= new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);

        recyclerView.addItemDecoration(new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL));

        recyclerView.setAdapter(leaderBoardAdapter);

        leaderBoardAdapter.setOnItemClickListener(new LeaderBoardAdapter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {

                Profile p=allProfileDataList.get(position);
                String s=allStdId.get(position);
                String im=imgStoreList.get(position);
                Intent i=new Intent(LeaderBoard.this,AddReward.class);
                i.putExtra("ToRewardUsername",p.getUserName());
                i.putExtra("ToRewardDep",p.getDep());
                i.putExtra("ToRewardPosition",p.getPosition());
                i.putExtra("ToRewardPoint",p.getPoint());
                i.putExtra("ToRewardFirstName",p.getFirstName());
                i.putExtra("ToRewardLastName",p.getLastName());
                i.putExtra("ToRewardSourceUserName",userName);
                i.putExtra("ToRewardSourcePassword",password);
                i.putExtra("targetStdId",s);
                i.putExtra("imageFromLead",im);
                i.putExtra("storyFromLeaderBoard",p.getStory());

                startActivity(i);
            }
        });

        try{

            if(uN!=null && ps!=null) {
                new GetAllProfilesAPIAsynkTask(this).execute("A20424085",uN,ps);
            }else{

                JSONObject obj=new JSONObject(data);
                userName=obj.getString("username");
                password=obj.getString("password");

                new GetAllProfilesAPIAsynkTask(this).execute("A20424085",userName,password);

            }

        }catch (Exception e){
            Log.e("LeaderBoard","error in lead ");
        }

        leaderBoardAdapter.notifyDataSetChanged();
    }

    public void displayToast(String result) {

        try {
            JSONArray array = new JSONArray(result);

            for(int i=0;i<= array.length();i++){

                JSONObject object=array.getJSONObject(i);
                String uname=object.getString("username");
                String pos=object.getString("position");
                String dep=object.getString("department");
                String point=object.getString("pointsToAward");
                String firstName=object.getString("firstName");
                String lastName=object.getString("lastName");
                String sId=object.getString("studentId");
                String img=object.getString("imageBytes");

                imgStoreList.add(img);

                totalValue=0;

                String re="";
                if(object.isNull("rewards")){
                    totalValue=0;
                }else{
                    re=object.optString("rewards");
                }
                if(!re.equals("")){

                   JSONArray array2=new JSONArray(object.getString("rewards"));
                    for(int j=0;j<array2.length();j++){

                        JSONObject jsonObject=array2.getJSONObject(j);

                        String total=jsonObject.getString("value");
                        totalValue=totalValue + Integer.parseInt(total);

                    }

                }

                allStdId.add(sId);
                Profile profile=new Profile(uname,dep,pos,totalValue+"",firstName,lastName, object.getString("story"));
                allProfileDataList.add(profile);

                leaderBoardAdapter.notifyDataSetChanged();

            }

        }catch (Exception e){
            e.printStackTrace();
            Log.e(">>>>>","LeaderBoard displayToast Error");
        }

    }
}
