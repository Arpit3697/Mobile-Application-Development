package com.example.inspirationrewards;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class RewardHistoryAdapter extends RecyclerView.Adapter<RewardHistoryAdapter.MyViewHolder> {


    List<RewardHistory> allHistoryData;

    public RewardHistoryAdapter(List<RewardHistory> allHistoryData){
        this.allHistoryData=allHistoryData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.reward_history_single,viewGroup,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {

        RewardHistory r=allHistoryData.get(i);
        myViewHolder.name.setText(r.getName());
        myViewHolder.rewardPoint.setText(r.getPoint());
        myViewHolder.date.setText(r.getDate());
        myViewHolder.note.setText(r.getNote());
    }

    @Override
    public int getItemCount() {
        return allHistoryData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView rewardPoint,name,date,note;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.reward_history_name);
            rewardPoint=itemView.findViewById(R.id.reward_history_point);
            date=itemView.findViewById(R.id.reward_history_date);
            note=itemView.findViewById(R.id.reward_history_notes);
        }
    }
}
