package com.example.inspirationrewards;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.inspirationrewards.AsyncTask.RewardAPIAsyncTask;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AddReward extends AppCompatActivity {

    TextView firstName,position,department,pointNumber,story;
    EditText getRewardPoint,getComment;
    ImageView imageView;

    String sUserName,sPassword;

    String depFrom,posFrom,pointFrom,fNameFrom,lNameFrom,unameFrom,image;
    String targetStdId;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.save_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

       Date c = Calendar.getInstance().getTime();
       SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
       String formattedDate = df.format(c);

       String re=getRewardPoint.getText().toString();
       String rc=getComment.getText().toString();

       new RewardAPIAsyncTask(AddReward.this).execute("A20424085",sUserName,sPassword,targetStdId,unameFrom,fNameFrom+ " "+lNameFrom,formattedDate,rc,
               re);
       Intent i =new Intent(AddReward.this,LeaderBoard.class);
       i.putExtra("Uname",sUserName);
       i.putExtra("Pass",sPassword);
       startActivity(i);
       finish();
       return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_reward);

        Intent i=getIntent();

        unameFrom=i.getStringExtra("ToRewardUsername");
        depFrom=i.getStringExtra("ToRewardDep");
        posFrom=i.getStringExtra("ToRewardPosition");
        pointFrom=i.getStringExtra("ToRewardPoint");
        fNameFrom=i.getStringExtra("ToRewardFirstName");
        lNameFrom=i.getStringExtra("ToRewardLastName");
        sUserName=i.getStringExtra("ToRewardSourceUserName");
        sPassword=i.getStringExtra("ToRewardSourcePassword");
        targetStdId=i.getStringExtra("targetStdId");
        image=i.getStringExtra("imageFromLead");
        String st=i.getStringExtra("storyFromLeaderBoard");

        firstName=findViewById(R.id.add_reward_username);
        pointNumber=findViewById(R.id.add_reward_point);
        department=findViewById(R.id.add_reward_department);
        position=findViewById(R.id.add_reward_position);
        imageView=findViewById(R.id.add_reward_imageview);
        story=findViewById(R.id.add_reward_story);

        getRewardPoint=findViewById(R.id.add_reward_edit_point);
        getComment=findViewById(R.id.add_reward_comment);

        getSupportActionBar().setTitle(fNameFrom+" "+lNameFrom);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        firstName.setText(fNameFrom+","+lNameFrom);
        pointNumber.setText(pointFrom);
        department.setText(depFrom);
        position.setText(posFrom);
        story.setText(st);

        InputStream stream = new ByteArrayInputStream(Base64.decode(image.getBytes(), Base64.DEFAULT));
        Bitmap bitmap = BitmapFactory.decodeStream(stream);
        imageView.setImageBitmap(bitmap);
    }

    public void displayToast(String result) {

        if(result.equals("Failed")){

        }else{
            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
        }
    }
}
