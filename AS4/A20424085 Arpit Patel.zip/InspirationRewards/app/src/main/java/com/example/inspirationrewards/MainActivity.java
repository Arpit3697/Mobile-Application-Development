package com.example.inspirationrewards;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.Manifest;

import com.example.inspirationrewards.AsyncTask.Delete;
import com.example.inspirationrewards.AsyncTask.LoginAPIAsyncTask;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    EditText uName,pwd;
    Button loginButton;
    ProgressBar progressBar;
    CheckBox checkBox;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        setContentView(R.layout.activity_main);

        checkLocationPermission();
        ConstraintLayout layout=findViewById(R.id.constraint_layout);
        Drawable d=getDrawable(R.drawable.background);
        d.setAlpha(100);
        layout.setBackground(d);
     //new Delete(this).execute("A20424085","nisarg123","nisarg123");

        uName=findViewById(R.id.main_username);
        pwd=findViewById(R.id.main_password);
        loginButton=findViewById(R.id.main_login_button);
        progressBar=findViewById(R.id.progressBar);
        checkBox=findViewById(R.id.main_save_data);

        SharedPreferences prefs = getSharedPreferences("CONFIDENTIAL", MODE_PRIVATE);

        String userName="";
        String pass="";
        try{

            userName= prefs.getString("username", null);
            pass=prefs.getString("password",null);

            if (userName != null) {

                checkBox.setChecked(true);
                uName.setText(userName);
                pwd.setText(pass);
            }

        }catch (Exception e){
            Log.e(">>>>>>>","No saved User");
        }

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                progressBar.setVisibility(View.VISIBLE);
                if(checkBox.isChecked()){
                    SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("CONFIDENTIAL",Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("username",uName.getText().toString());
                    editor.putString("password",pwd.getText().toString());
                    editor.apply();
                }

                new LoginAPIAsyncTask(MainActivity.this).execute("A20424085",uName.getText().toString(),pwd.getText().toString());

            }
        });
    }

    public void performClick(View v){
        startActivity(new Intent(MainActivity.this,CreateProfile.class));
    }

    public void displayToast(String result) {

      // Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
        if(!result.equals("Failed")){

            try{
                Intent i=new Intent(MainActivity.this,YourProfile.class);
                i.putExtra("Details",result);
                startActivity(i);
                progressBar.setVisibility(View.GONE);
            }catch (Exception e){
             Log.e(">>Error in MainActivity","DisplayTOast");
            }
        }else{
            progressBar.setVisibility(View.GONE);
            Toast.makeText(getApplicationContext(),"Login Failed",Toast.LENGTH_SHORT).show();
        }

    }
    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle("Location Permission")
                        .setMessage("Give Permission")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        //Request location updates:
                       // locationManager.requestLocationUpdates(provider, 400, 1, this);
                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.

                }
                return;
            }

        }
    }
}