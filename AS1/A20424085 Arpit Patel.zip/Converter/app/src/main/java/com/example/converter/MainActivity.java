package com.example.converter;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button mConvertButton;
    EditText mLayout;
    EditText mDispay;
    TextView mHistory;
    RadioGroup mRadioGroup;
    RadioButton mF2CButton;
    RadioButton mC2FButton;
    TextView F2C;
    TextView C2F;
    Double d;
    Button clear;
    StringBuilder scg = new StringBuilder();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mLayout=findViewById(R.id.User_input);
        mConvertButton=findViewById(R.id.button_convert);
        mDispay=findViewById(R.id.editText_result_output);
        mF2CButton=findViewById(R.id.radioButton_F2C);
        mC2FButton=findViewById(R.id.radioButton_C2F);
        mRadioGroup = findViewById(R.id.radioGroup);
        F2C=findViewById(R.id.textView_FD);
        C2F=findViewById(R.id.textView_CD);
        mHistory=findViewById(R.id.edittext_history);
        mHistory.setMovementMethod(new ScrollingMovementMethod());
        clear=findViewById(R.id.button_clear);

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               mHistory.setText("");
            }
        });

        mConvertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mF2CButton.isChecked()){
                    F2C.setText("Fahrenheit Degrees:");
                    C2F.setText("Celsius Degrees");
                    String user=mLayout.getText().toString();
                    d=Double.parseDouble(user);
                    Double convertNumber=d-32.0;
                    convertNumber=convertNumber/1.8;

                    mDispay.setText(String.format("%.1f",convertNumber));
                    String str = user+" F"+" ==>"+String.format("%.1f",convertNumber)+"C\n";
                    mHistory.setText(scg.insert(0,str));
                }
                else{
                    F2C.setText("Celsius Degrees:");
                    C2F.setText("Fahrenheit Degrees:");
                    String user=mLayout.getText().toString();
                    d=Double.parseDouble(user);
                    Double convertNumber=d*1.8;
                    convertNumber=convertNumber + 32;
                    mDispay.setText(String.format("%.1f",convertNumber));
                    String str = user+" c"+" ==>"+String.format("%.1f",convertNumber)+"F\n";
                    mHistory.setText(scg.insert(0,str));
                }

            }
        });

        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radioButton_F2C:
                        F2C.setText("Fahrenheit Degrees:");
                        C2F.setText("Celsius Degrees:");

                        break;

                    case R.id.radioButton_C2F:
                        F2C.setText("Celsius Degrees:");
                        C2F.setText("Fahrenheit Degrees:");


                        break;
                }
            }
                });

                }
                
    }

