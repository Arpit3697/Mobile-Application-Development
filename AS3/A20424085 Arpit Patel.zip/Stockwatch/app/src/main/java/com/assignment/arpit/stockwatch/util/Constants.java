package com.assignment.arpit.stockwatch.util;

public interface Constants {
    String MARKET_WATCH_URL = "https://www.marketwatch.com/investing/stock/";
    String STOCK_SYMBOLS_URL = "https://api.iextrading.com/1.0/ref-data/symbols";
    String STOCK_DOWNLOAD_MAIN_URL = "https://api.iextrading.com/1.0/stock/";
    String STOCK_DOWNLOAD_QUERY_URL = "/quote?displayPercent=true";

    String HTTP_CALL_GET = "GET";
}
