package com.assignment.arpit.stockwatch.remote;



import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import com.assignment.arpit.stockwatch.model.StockResponse;
import com.assignment.arpit.stockwatch.ui.MainActivity;
import com.assignment.arpit.stockwatch.util.Constants;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class StockDownloadAsyncTask extends AsyncTask<String, Void, StockResponse> {

    private static final String TAG = "StockDownloadAsyncTask";

    @SuppressLint("StaticFieldLeak")
    private MainActivity mainActivity;

    public StockDownloadAsyncTask(MainActivity main) {
        mainActivity = main;
    }


    @Override
    protected StockResponse doInBackground(String... strings) {
        Uri.Builder buildURL = Uri.parse(Constants.STOCK_DOWNLOAD_MAIN_URL + strings[0] + Constants.STOCK_DOWNLOAD_QUERY_URL).buildUpon();
        String urlToUse = buildURL.build().toString();
        Log.d(TAG, "doInBackground: " + urlToUse);

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(Constants.HTTP_CALL_GET);
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (Exception e) {
            return null;
        }

        return parseJSONData(sb.toString());
    }

    @Override
    protected void onPostExecute(StockResponse stockResponse) {
        super.onPostExecute(stockResponse);
        mainActivity.updateStockList(stockResponse);
    }

    StockResponse parseJSONData(String s) {
        StockResponse stockResponse = new StockResponse();
        try {
            JSONObject obj = new JSONObject(s);
            stockResponse.setStockSymbol(obj.getString("symbol"));
            stockResponse.setCompanyName(obj.getString("companyName"));
            stockResponse.setStockPrice(obj.getDouble("latestPrice"));
            stockResponse.setPriceChange(obj.getDouble("change"));
            stockResponse.setPercentageChange(obj.getDouble("changePercent"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return stockResponse;

    }
}
