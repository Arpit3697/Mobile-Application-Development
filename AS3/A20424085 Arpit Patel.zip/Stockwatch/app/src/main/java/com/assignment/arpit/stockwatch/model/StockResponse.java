package com.assignment.arpit.stockwatch.model;

public class StockResponse {

    private String stockSymbol;
    private String companyName;
    private double stockPrice;
    private double priceChange;
    private double percentageChange;

    public StockResponse(String stockSymbol, String companyName, double stockPrice, double priceChange, double percentageChange){
        this.stockSymbol=stockSymbol;
        this.companyName=companyName;
        this.stockPrice = stockPrice;
        this.priceChange=priceChange;
        this.percentageChange=percentageChange;
    }


    public String getStockSymbol() {
        return stockSymbol;
    }

    public void setStockSymbol(String stockSymbol) {
        this.stockSymbol = stockSymbol;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public double getStockPrice() {
        return stockPrice;
    }

    public void setStockPrice(double stockPrice) {
        this.stockPrice = stockPrice;
    }

    public double getPriceChange() {
        return priceChange;
    }

    public void setPriceChange(double priceChange) {
        this.priceChange = priceChange;
    }

    public double getPercentageChange() {
        return percentageChange;
    }

    public void setPercentageChange(double percentageChange) {
        this.percentageChange = percentageChange;
    }

    public StockResponse(){}

    public String toString()
    {
        String stock;

        stock = this.getStockSymbol() + "/t" + this.getCompanyName()+"/t" +
                Double.toString(this.getStockPrice())+ "/t" + Double.toString(this.getPriceChange())+ "/t" +
                Double.toString(this.getPercentageChange());

        return stock;
    }


}
