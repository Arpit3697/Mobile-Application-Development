package com.assignment.arpit.stockwatch.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import com.assignment.arpit.stockwatch.R;
import com.assignment.arpit.stockwatch.db.StockDatabaseHandler;
import com.assignment.arpit.stockwatch.model.StockResponse;
import com.assignment.arpit.stockwatch.remote.StockDownloadAsyncTask;
import com.assignment.arpit.stockwatch.remote.StockNameDownloadAsyncTask;
import com.assignment.arpit.stockwatch.util.Constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity implements StockAdapter.ItemCallBacks {


    ArrayList<String[]> dBStocks = new ArrayList<>();
    private RecyclerView rvStock;
    private StockAdapter stockAdapter;
    private SwipeRefreshLayout srMain;
    private List<StockResponse> stockList = new ArrayList<>();
    private HashMap<String, String> hashMap = new HashMap<>();
    private StockDatabaseHandler databaseHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewSetup();
        valueSetup();
    }

    private void viewSetup() {
        rvStock = findViewById(R.id.rv_stock);
        srMain = findViewById(R.id.sr_main);
        stockAdapter = new StockAdapter(stockList, this);
        rvStock.setAdapter(stockAdapter);
        srMain.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        Toast.makeText(getApplicationContext(), "Refreshing..", Toast.LENGTH_SHORT).show();
                        srMain.setRefreshing(false);
                        loadStocksFromDB();
                    }

                });
    }

    private void valueSetup() {
        StockNameDownloadAsyncTask nd = new StockNameDownloadAsyncTask(this);
        nd.execute();

        loadStocksFromDB();
    }


    public void loadStocksFromDB() {
        databaseHandler = new StockDatabaseHandler(this);
        dBStocks = databaseHandler.loadStocks();
        if (isNetworkAvailable()) {
            stockList.clear();
            for (int i = 0; i < dBStocks.size(); i++) {
                StockDownloadAsyncTask sd = new StockDownloadAsyncTask(this);
                sd.execute(dBStocks.get(i)[0]);
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("No Network Connection");
            builder.setMessage("Stocks Cannot Be Updated Without A Network Connection");
            AlertDialog alert = builder.create();
            alert.show();
        }
    }

    public void getStockSymbolData(HashMap stockData) {
        hashMap = stockData;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            return false;
        }
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
            StockNameDownloadAsyncTask alt = new StockNameDownloadAsyncTask(this);
            alt.execute();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.opt_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.addStock:
                if (isNetworkAvailable()) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    LayoutInflater inflater = this.getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.view_stock, null);
                    builder.setView(dialogView);

                    final EditText editText = (EditText) dialogView.findViewById(R.id.editTextAddStock);
                    editText.setFilters(new InputFilter[]{new InputFilter.AllCaps()});

                    builder.setTitle("Stock Selection");
                    builder.setMessage("Please enter a Stock Symbol:");

                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ArrayList<String> results = new ArrayList<String>();
                            String searchedStockSymbol = editText.getText().toString().trim();
                            results = searchStock(searchedStockSymbol);
                            if (results == null || results.size() == 0) {
                                dialogNoMatchStock(searchedStockSymbol);
                            } else if (results.size() == 1) {
                                StockDownloadAsyncTask alt = new StockDownloadAsyncTask(MainActivity.this);
                                alt.execute(results.get(0).toString());
                            } else {
                                dialogMutipleStock(results);
                            }
                        }
                    });

                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    AlertDialog alert = builder.create();
                    alert.show();
                } else {

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("No Network Connection");
                    builder.setMessage("Stocks Cannot Be Added Without A Network Connection");
                    AlertDialog alert = builder.create();
                    alert.show();
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public ArrayList<String> searchStock(String regex) {

        ArrayList<String> stocks = new ArrayList<String>();
        Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Iterator<String> keysIterator = hashMap.keySet().iterator();
        while (keysIterator.hasNext()) {
            String candidate = keysIterator.next();
            Matcher m = p.matcher(candidate);
            if (m.find()) {
                System.out.println("it matches" + candidate);
                stocks.add(candidate);
            }
        }
        return stocks;
    }

    private void dialogNoMatchStock(String stock) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Symbol Not Found: " + stock);
        builder.setMessage("Data for stock symbol");
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void dialogMutipleStock(ArrayList<String> stocks) {

        Toast.makeText(this, "Multiple stocks", Toast.LENGTH_SHORT);

        final ArrayAdapter<String> multipleStocksMenu = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1);

        for (int i = 0; i < stocks.size(); i++) {
            multipleStocksMenu.add(stocks.get(i) + "-" + hashMap.get(stocks.get(i)));
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final StockDownloadAsyncTask sd = new StockDownloadAsyncTask(this);
        builder.setAdapter(multipleStocksMenu, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String s = multipleStocksMenu.getItem(which);
                if (s != null) {
                    String parts[] = s.split("-", 2);
                    sd.execute(parts[0]);
                }
            }
        });

        builder.setTitle("Make a selection");
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }


    public void updateStockList(StockResponse stockResponse) {
        boolean duplicateFlag = false;
        if (stockResponse != null) {
            for (int i = 0; i < stockList.size(); i++) {
                if (stockList.get(i).getStockSymbol().equalsIgnoreCase(stockResponse.getStockSymbol())) {
                    duplicateFlag = true;
                    break;
                }
            }
            if (duplicateFlag) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Duplicate Stock");
                builder.setMessage("Stock Symbol " + stockResponse.getStockSymbol() + " is already displayed");

                AlertDialog alert = builder.create();
                alert.show();
            } else {
                stockList.add(stockResponse);
                Collections.sort(stockList, new Comparator<StockResponse>() {
                    @Override
                    public int compare(StockResponse o1, StockResponse o2) {
                        return o1.getStockSymbol().compareTo(o2.getStockSymbol());
                    }
                });
                databaseHandler.addStock(stockResponse);
            }
        }
        stockAdapter.setItems(stockList);
    }

    @Override
    public void onItemClick(int position) {
        StockResponse stockResponse = stockList.get(position);
        Toast.makeText(getApplicationContext(), "Selected: " + stockResponse.getStockSymbol(), Toast.LENGTH_SHORT).show();

        Intent webBrowserIntent = new Intent(Intent.ACTION_VIEW);
        webBrowserIntent.setData(Uri.parse(Constants.MARKET_WATCH_URL + stockResponse.getStockSymbol()));
        startActivity(webBrowserIntent);
    }

    @Override
    public void onLongClick(final int position) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Stock");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                databaseHandler.deleteStock(stockList.get(position).getStockSymbol());
                stockList.remove(position);
                stockAdapter.setItems(stockList);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.setMessage("Delete Stock " + stockList.get(position).getStockSymbol() + "?");
        builder.setTitle("Delete Stock");

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        String[] strings= new  String[stockList.size()];
        for (int i = 0; i < stockList.size(); i++) {
            StockResponse stockResponse = stockList.get(i);
            strings[i] = stockResponse.toString();
        }
        outState.putStringArrayList("Data" , new ArrayList<>(Arrays.asList(strings)));
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        String[] strings= new  String[stockList.size()];
        for (int i = 0; i < stockList.size(); i++) {
            StockResponse stockResponse = stockList.get(i);
            strings[i] = stockResponse.toString();
        }
        outState.putStringArrayList("Data" , new ArrayList<>(Arrays.asList(strings)));
    }


    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        ArrayList<String> arrayList = savedInstanceState.getStringArrayList("Data");
        List<StockResponse> list  = null;
        if (arrayList != null) {
            list = new ArrayList<>(arrayList.size());
            for (int i = 0; i < arrayList.size(); i++) {
                String s = arrayList.get(i);
                String[] strings = s.split("/t");
                StockResponse stockResponse = new StockResponse();
                stockResponse.setStockSymbol(strings[0]);
                stockResponse.setCompanyName(strings[1]);
                stockResponse.setStockPrice(Double.parseDouble(strings[2]));
                stockResponse.setPriceChange(Double.parseDouble(strings[3]));
                stockResponse.setPercentageChange(Double.parseDouble(strings[4]));

                list.add(stockResponse);
            }
        }
        stockAdapter.setItems(list);
    }
}
