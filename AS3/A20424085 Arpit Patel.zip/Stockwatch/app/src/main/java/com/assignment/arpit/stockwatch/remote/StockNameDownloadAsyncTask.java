package com.assignment.arpit.stockwatch.remote;

import android.net.Uri;
import android.os.AsyncTask;


import com.assignment.arpit.stockwatch.ui.MainActivity;
import com.assignment.arpit.stockwatch.util.Constants;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

public class StockNameDownloadAsyncTask extends AsyncTask<String, Void, String> {
    private MainActivity mainActivity;
    private HashMap<String, String> stockData = new HashMap<>();

    public StockNameDownloadAsyncTask(MainActivity mainActivity) {
        this.mainActivity= mainActivity;
    }

    @Override
    protected String doInBackground(String... strings) {
        Uri.Builder buildURL = Uri.parse(Constants.STOCK_SYMBOLS_URL).buildUpon();
        String urlToUse = buildURL.build().toString();

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(Constants.HTTP_CALL_GET);
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (Exception e) {
            return null;
        }
        parseJSONData(sb.toString());
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        try {
            if (mainActivity != null) {
                mainActivity.getStockSymbolData(stockData);
            } else {
            throw new Exception();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void parseJSONData(String s) {
        try {
            JSONArray jsonArray = new JSONArray(s);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                stockData.put(jsonObject.getString("symbol"), jsonObject.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
