package com.example.multi_notepad;

import android.content.DialogInterface;
import android.content.Intent;

import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.JsonWriter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class EditActivity extends AppCompatActivity {

    EditText title,note;
    String titleFromMain,noteFromMain;
    int backpressed=1;//goto back

    @Override
    protected void onStop(){
        super.onStop();
        if(backpressed==1){
            updateData();

            if(titleFromMain==null ){
                saveData();
            }
            Toast.makeText(getApplicationContext(),"Note Saved",Toast.LENGTH_SHORT).show();

         }else if(backpressed==2){
            saveData();
            Toast.makeText(getApplicationContext(),"Note Saved",Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu2,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public void onBackPressed() {

        backpressed=0;
        if(title.getText().toString().equals("")&& note.getText().toString().equals("")){
            finish();
        }else if(titleFromMain.equals(title.getText().toString()) && noteFromMain.equals(note.getText().toString())){
           finish();
        }else{
            new AlertDialog.Builder(EditActivity.this).setMessage("Do you want to Save Note")
                    .setPositiveButton("Yes",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    updateData();
                                }
                            })
                    .setNegativeButton("NO",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    startActivity(new Intent(EditActivity.this,MainActivity.class));
                                }
                            }).show();
        }

    }//End of onBackPressed


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        backpressed=0;
        if(titleFromMain==null && noteFromMain==null){
            backpressed=1;
            saveData();
        }else{
            backpressed=1;
            updateData();
        }

        return super.onOptionsItemSelected(item);
    }//End of onOptionItemSelected method

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_activtiy);

        title=findViewById(R.id.edit_activity_title);
        note=findViewById(R.id.edit_activity_note);


        Intent intent=getIntent();
        titleFromMain=intent.getStringExtra("title");
        noteFromMain=intent.getStringExtra("note");
        title.setText(titleFromMain);
        note.setText(noteFromMain);

    }//End of onCreate() method


        public void saveData(){
        try{

            if(TextUtils.isEmpty(title.getText().toString())){
                Toast.makeText(getApplicationContext(),"Untitled Note not saved",Toast.LENGTH_SHORT).show();
                backpressed=0;
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();

            }else{
                //-------------------------------------------------
                String json="";
                try{
                    FileInputStream fin=openFileInput("note.json");
                    int sizeF=fin.available();
                    byte[] bufferF=new byte[sizeF];
                    fin.read(bufferF);
                    fin.close();
                    json= new String(bufferF,"UTF-8");
                }catch (Exception e){

                    if(e instanceof FileNotFoundException){
                        FileOutputStream outputStream=openFileOutput("note.json",MODE_PRIVATE);
                    }
                }//End of catch

                //--------------------------------
                JSONArray jsonArray;
                if(json.equals("")){
                    jsonArray=new JSONArray();
                }else{
                    jsonArray=new JSONArray(json);
                }

                FileOutputStream outputStream=openFileOutput("note.json",MODE_PRIVATE);
                outputStream.write("".getBytes());
                JSONObject jsonObject=new JSONObject();

                jsonObject.put("title",title.getText().toString());
                Date currenTime= Calendar.getInstance().getTime();
                long longTime=currenTime.getTime();
                jsonObject.put("sorttime",longTime);
                jsonObject.put("date",currenTime.toString());
                jsonObject.put("note",note.getText().toString());


                jsonArray.put(jsonObject);
                outputStream.write(jsonArray.toString().getBytes());

                backpressed=3;
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }//End of else

        }catch (Exception e){
            Log.e("EditActivity","error in optionitem selected",e);
            Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_SHORT).show();
        }

    }//End of saveData Method

    public void updateData(){

            String json="";
            try{
                FileInputStream fin=openFileInput("note.json");
                int sizeF=fin.available();
                byte[] bufferF=new byte[sizeF];
                fin.read(bufferF);
                fin.close();
                json= new String(bufferF,"UTF-8");
                JSONArray jsonArray=new JSONArray(json);

                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject=jsonArray.getJSONObject(i);

                    String jsonTitle=jsonObject.getString("title");
                    String jsonNote=jsonObject.getString("note");

                   //title from main and when button pressed title same means no update in title
                    if(jsonTitle.equals(title.getText().toString())){
                        if(jsonNote.equals(note.getText().toString())){

                        }else{
                            //Differrent note so update file

                            jsonObject.put("note",note.getText().toString());
                            Date currenTime= Calendar.getInstance().getTime();
                            long longTime=currenTime.getTime();
                            jsonObject.put("sorttime",longTime);
                            jsonObject.put("date",currenTime.toString());
                            break;
                        }

                    }else{

                        if(jsonTitle.equals(titleFromMain)){
                            jsonObject.put("title",title.getText().toString());
                            jsonObject.put("note",note.getText().toString());
                            Date currenTime= Calendar.getInstance().getTime();
                            long longTime=currenTime.getTime();
                            jsonObject.put("sorttime",longTime);
                            jsonObject.put("date",currenTime.toString());
                            break;

                        }

                    }
                }//End of if

                FileOutputStream outputStream=openFileOutput("note.json",MODE_PRIVATE);
                outputStream.write("".getBytes());

                outputStream.write(jsonArray.toString().getBytes());
                backpressed=0;
                startActivity(new Intent(EditActivity.this,MainActivity.class));
                finish();
            }catch (Exception e){
                    Log.e("error in edit","updatedata");
            }//End of catch
        }

}//End of EditActivity class
