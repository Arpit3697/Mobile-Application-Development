package com.example.multi_notepad;

public class Note {
 private String title,date,note;
 private long sortTime;
 public Note(){

 }

 public Note(String title,String date, String first_character,long sortTime){

     this.title=title;
     this.date=date;
     note=first_character;
     this.sortTime=sortTime;
 }


    public long getSortTime() {
        return sortTime;
    }

    public void setSortTime(long sortTime) {
        this.sortTime = sortTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getFirst_character() {
        return note;
    }

    public void setFirst_character(String first_character) {
        this.note = first_character;
    }
}
