package com.example.multi_notepad;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    NoteAdapter mNoteAdapter;

    List<Note> noteList=new ArrayList<>();

    @Override
    protected void onPause() {
        super.onPause();

//        SharedPreferences preferences=getSharedPreferences("onpause",MODE_PRIVATE);
//        String id=preferences.getString("t","none");
//        Log.e(">>>>",id);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MainActivity.this.setTitle("Multi-Note Pad"+"("+(noteList.size())+")");
        recyclerView=findViewById(R.id.recycler_view);
        mNoteAdapter=new NoteAdapter(noteList);
        RecyclerView.LayoutManager mLayoutManager= new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(mNoteAdapter);
        //Load in asynk task
        new JSONParse().execute();

        mNoteAdapter.notifyDataSetChanged();
        //recyclerview click listener
        mNoteAdapter.setOnItemClickListener(new NoteAdapter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {

                Note note=noteList.get(position);
                Intent intent=new Intent(MainActivity.this,EditActivity.class);
                intent.putExtra("index",position);
                intent.putExtra("title",note.getTitle());
                intent.putExtra("note",note.getFirst_character());
                startActivity(intent);
                }

            @Override
            public void onItemLongClick(final int position, View v) {

                Note note=noteList.get(position);

                new AlertDialog.Builder(MainActivity.this)
                        .setMessage("Delete Note "+note.getTitle()+"?")
                        .setPositiveButton(
                                "YES",
                                new DialogInterface.OnClickListener() {
                                    public void onClick( DialogInterface dialog,int which) {

                                        Log.e("delete item",noteList.get(position).getTitle()+"?");

                                        noteList.remove(position);

                                        try{
                                            FileOutputStream outputStream=openFileOutput("note.json",MODE_PRIVATE);
                                            outputStream.write("".getBytes());
                                            JSONArray jsonArray=new JSONArray();

                                            for(int i=0;i<noteList.size();i++){
                                                JSONObject jsonObject=new JSONObject();
                                                Note tempStore=noteList.get(i);
                                                jsonObject.put("title",tempStore.getTitle());
                                                jsonObject.put("date",tempStore.getDate());
                                                jsonObject.put("note",tempStore.getFirst_character());
                                                jsonObject.put("sorttime",tempStore.getSortTime());
                                                jsonArray.put(jsonObject);
                                            }
                                            outputStream.write(jsonArray.toString().getBytes());
                                            mNoteAdapter.notifyDataSetChanged();
                                            MainActivity.this.setTitle("Multi-Note Pad"+"("+(noteList.size())+")");

                                        }catch (Exception e){
                                            Log.e("MainActivity","in method of long click error");
                                        }
                                        dialog.cancel();
                                    }
                                }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).show();
            }
        });


    }//onCreate method close

    class JSONParse extends AsyncTask<Void,Void,Void>{

        @Override
        protected Void doInBackground(Void... voids) {
            prepareNoteData();
            return null;
        }
    }//End of JSONParse Class

    private void prepareNoteData() {

                //create file in internal storage and give path
                try{
                    FileInputStream fin=openFileInput("note.json");
                    int sizeF=fin.available();
                    byte[] bufferF=new byte[sizeF];
                    fin.read(bufferF);
                    fin.close();

                    String json= new String(bufferF,"UTF-8");
                    JSONArray jsonArray=new JSONArray(json);

                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject object=jsonArray.getJSONObject(i);

                        String title=object.getString("title");
                        String date=object.getString("date");
                        String note4=object.getString("note");
                        long sortTime=object.getLong("sorttime");
                        Note note_4=new Note(title,date,note4,sortTime);

                        noteList.add(note_4);
                    }

                    Collections.sort(noteList, new Comparator<Note>() {
                        @Override
                        public int compare(Note o1, Note o2) {
                            return o1.getSortTime()<=o2.getSortTime()? 1 : -1;
                        }
                    });

                }catch (Exception e){
                    if(e instanceof FileNotFoundException){
                        Log.e("MainActivity","file not found");
                    }
                    if(e instanceof JSONException){
                        e.printStackTrace();
                        Log.e("jsonexception","json error",e);
                        }
                    }
                    mNoteAdapter.notifyDataSetChanged();
        MainActivity.this.setTitle("Multi-Note Pad"+"("+(noteList.size())+")");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main_menu,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_about_activity:

                startActivity(new Intent(this,AboutActivity.class));
                return true;

            case R.id.action_edit_activity:

                startActivity(new Intent(this, EditActivity.class));
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }//onOptionItemSelected close

}
