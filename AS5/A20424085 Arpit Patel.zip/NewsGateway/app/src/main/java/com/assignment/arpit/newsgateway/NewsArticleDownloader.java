package com.assignment.arpit.newsgateway;

import android.net.Uri;
import android.os.AsyncTask;

import com.assignment.arpit.newsgateway.Modal.Article;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class NewsArticleDownloader extends AsyncTask<String, Integer, String> {

    private final String URL_HEAD = "https://newsapi.org/v2/everything?language=en&pageSize=100&sources=";
    private final String URL_TAIL = "&apiKey=";
    private final String KEY = "d182fa6abea945259535f62cd31607ff";
    static NewsServices newsServices = new NewsServices();

    @Override
    protected void onPostExecute(String s) {
        ArrayList<Article> articles_data = parseJSON(s);
        newsServices.setArticles(articles_data);
    }

    @Override
    protected String doInBackground(String... params) {
        Uri dataUri;
        dataUri = Uri.parse(URL_HEAD + params[0].toLowerCase() + URL_TAIL + KEY);
        String urlToUse = dataUri.toString();

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlToUse);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            int HTTP_NOT_FOUND = conn.getResponseCode();
            if (HTTP_NOT_FOUND == 404) {
                return null;
            } else {
                conn.setRequestMethod("GET");
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                return sb.toString();

            }
        } catch (Exception e) {
            return null;
        }
    }

    private ArrayList<Article> parseJSON(String s) {
        try {
            ArrayList<Article> articalList = new ArrayList<>();
            String author = null, title = null, description = null, urlToImage = null, publishedAt = null, news_url = null;
            JSONObject jObjMain = new JSONObject(s);

            JSONArray articles = jObjMain.getJSONArray("articles");
            for (int i = 0; i < articles.length(); i++) {
                JSONObject source_object = (JSONObject) articles.get(i);
                author = source_object.getString("author");
                title = source_object.getString("title");
                description = source_object.getString("description");
                urlToImage = source_object.getString("urlToImage");
                publishedAt = source_object.getString("publishedAt");
                news_url = source_object.getString("url");
                articalList.add(new Article(author, title, description, urlToImage, publishedAt, news_url));
            }
            return articalList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}

